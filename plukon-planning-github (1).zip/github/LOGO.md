# 🖼️ Logo Plukon - Guide d'Utilisation

## ✅ Le Logo est Intégré !

Le fichier `logo-plukon.png` est inclus dans ce package et sera **automatiquement chargé** dans les PDF.

---

## 📁 Structure des Fichiers

```
plukon-planning/
├── index.html          ← Application principale
├── logo-plukon.png     ← Logo Plukon (149 Ko)
├── README.md
├── LICENSE
└── DEPLOIEMENT.md
```

**IMPORTANT** : Les fichiers `index.html` et `logo-plukon.png` doivent être dans le **même dossier** !

---

## 🚀 Publication sur GitHub

### Option 1 : Upload via Interface Web (Recommandé)

1. Créez votre repository sur GitHub
2. Cliquez sur **"uploading an existing file"**
3. Glissez-déposez **TOUS** les fichiers en même temps :
   - ✅ `index.html`
   - ✅ `logo-plukon.png`
   - ✅ `README.md`
   - ✅ `LICENSE`
   - ✅ `.gitignore` (si présent)
4. Commit changes
5. Activez GitHub Pages

### Option 2 : Upload via Git

```bash
git init
git add .
git commit -m "Ajout application Plukon Planning avec logo"
git branch -M main
git remote add origin https://github.com/VOTRE-USERNAME/plukon-planning.git
git push -u origin main
```

---

## 🎨 Le Logo dans le PDF

### Chargement Automatique
- L'application charge automatiquement `logo-plukon.png` au démarrage
- Le logo apparaît en haut à gauche du PDF
- Dimensions dans le PDF : 50mm x 20mm

### Vérification du Chargement
Ouvrez la console du navigateur (F12) :
- ✅ Si le logo est chargé : `✅ Logo chargé pour export PDF`
- ⚠️ Si erreur : `⚠️ Logo non disponible: [raison]`

### En cas de Problème

#### Le logo ne s'affiche pas dans le PDF ?

**Vérifications :**
1. ✅ Les fichiers `index.html` et `logo-plukon.png` sont dans le même dossier
2. ✅ Le nom du fichier est exactement `logo-plukon.png` (minuscules)
3. ✅ Pas d'espace dans le nom du fichier
4. ✅ Videz le cache du navigateur (Ctrl+Shift+R)

**Solution si ça ne fonctionne toujours pas :**
Si vous voyez "PLUKON food group" en texte au lieu du logo, c'est normal :
- Le texte est un **fallback** (remplacement)
- Il garantit que le PDF est toujours généré même sans logo

---

## 🖼️ Remplacer le Logo

### Si vous voulez utiliser un autre logo :

1. Préparez votre logo au format PNG
2. Nommez-le exactement `logo-plukon.png`
3. Remplacez l'ancien fichier
4. Dimensions recommandées : 976x400 px (ou ratio 2.44:1)

### Si vous voulez changer le nom du fichier :

Éditez `index.html` ligne ~954 :
```javascript
img.src = 'logo-plukon.png';  // ← Changez ici
```

---

## 💻 Test Local

### Avant de publier sur GitHub, testez localement :

1. Placez `index.html` et `logo-plukon.png` dans le même dossier
2. Double-cliquez sur `index.html`
3. Ouvrez la console (F12)
4. Vérifiez le message : `✅ Logo chargé pour export PDF`
5. Créez un planning et exportez en PDF
6. Le logo doit apparaître dans le PDF

---

## 🌐 Sur GitHub Pages

### Une fois publié sur GitHub :

L'URL sera :
```
https://VOTRE-USERNAME.github.io/plukon-planning/
```

Le logo sera chargé depuis :
```
https://VOTRE-USERNAME.github.io/plukon-planning/logo-plukon.png
```

**Tout fonctionne automatiquement !**

---

## ⚙️ Détails Techniques

### Format du Logo
- **Type** : PNG (avec transparence)
- **Taille** : 149 Ko
- **Dimensions** : 976 x 400 pixels
- **Ratio** : 2.44:1

### Dans le PDF
- **Position** : En haut à gauche (15mm, 5mm)
- **Taille** : 50mm x 20mm
- **Format** : PNG encodé en base64

### Chargement
```javascript
// Le logo est chargé au démarrage de l'application
loadLogoImage().then(dataUrl => {
  state.logoDataUrl = dataUrl;  // Stocké en base64
  console.log('✅ Logo chargé pour export PDF');
});
```

---

## 📝 Notes Importantes

### ✅ À Faire
- Gardez `index.html` et `logo-plukon.png` ensemble
- Uploadez les deux fichiers sur GitHub
- Vérifiez le chargement dans la console

### ❌ À Éviter
- Ne renommez pas le logo (sauf si vous modifiez le code)
- Ne déplacez pas le logo dans un sous-dossier
- N'utilisez pas de logo trop lourd (>500 Ko)

---

## 🎯 Résumé

1. ✅ Le logo `logo-plukon.png` est inclus
2. ✅ Il est chargé automatiquement au démarrage
3. ✅ Il apparaît dans chaque PDF exporté
4. ✅ Uploadez-le avec `index.html` sur GitHub
5. ✅ Tout fonctionne automatiquement !

---

**🎉 Votre application génère maintenant des PDF avec le logo Plukon !**
