# 🚀 Guide de Publication sur GitHub - Simple et Rapide

## Étapes Simples pour Publier

### 1️⃣ Créer un compte GitHub (si vous n'en avez pas)
1. Allez sur https://github.com
2. Cliquez sur "Sign up"
3. Créez votre compte gratuit

### 2️⃣ Créer un nouveau Repository
1. Une fois connecté, cliquez sur le **"+"** en haut à droite
2. Sélectionnez **"New repository"**
3. Remplissez :
   - **Repository name** : `plukon-planning`
   - **Description** : Application de gestion de planning Plukon
   - Cochez **"Public"**
   - ✅ Cochez **"Add a README file"**
4. Cliquez sur **"Create repository"**

### 3️⃣ Uploader les Fichiers
1. Dans votre nouveau repository, cliquez sur **"uploading an existing file"**
2. Glissez-déposez ces 3 fichiers :
   - ✅ `index.html` (le fichier principal)
   - ✅ `LICENSE`
   - ✅ `.gitignore`
3. Dans la section "Commit changes" :
   - Titre : `Ajout de l'application Plukon Planning`
4. Cliquez sur **"Commit changes"**

### 4️⃣ Activer GitHub Pages
1. Dans votre repository, cliquez sur **"Settings"** (⚙️)
2. Dans le menu gauche, cliquez sur **"Pages"**
3. Sous "Source" :
   - Branch : Sélectionnez `main`
   - Folder : `/ (root)`
4. Cliquez sur **"Save"**
5. ⏱️ Attendez 1-2 minutes

### 5️⃣ Accéder à Votre Application
Votre application sera disponible à :
```
https://VOTRE-NOM-UTILISATEUR.github.io/plukon-planning/
```

Remplacez `VOTRE-NOM-UTILISATEUR` par votre nom d'utilisateur GitHub.

---

## 📱 Créer un Raccourci sur Téléphone

### Sur iPhone/iPad
1. Ouvrez l'URL dans Safari
2. Appuyez sur le bouton **Partager** (carré avec flèche)
3. Faites défiler et sélectionnez **"Sur l'écran d'accueil"**
4. Nommez-le "Plukon Planning"
5. Appuyez sur **"Ajouter"**

### Sur Android
1. Ouvrez l'URL dans Chrome
2. Appuyez sur le menu **⋮** (3 points)
3. Sélectionnez **"Ajouter à l'écran d'accueil"**
4. Nommez-le "Plukon Planning"
5. Appuyez sur **"Ajouter"**

---

## 🔄 Mettre à Jour l'Application

Pour mettre à jour après des modifications :

1. Ouvrez votre repository sur GitHub
2. Cliquez sur le fichier `index.html`
3. Cliquez sur le crayon ✏️ **"Edit"**
4. Faites vos modifications
5. Cliquez sur **"Commit changes"**
6. Les changements seront en ligne après 1-2 minutes

---

## ❓ Aide Rapide

### L'application ne se charge pas ?
- ✅ Vérifiez que GitHub Pages est bien activé (Settings → Pages)
- ✅ Attendez 2-3 minutes après l'activation
- ✅ Videz le cache de votre navigateur (Ctrl+Shift+R)

### Je ne vois pas mon URL ?
- Retournez dans Settings → Pages
- L'URL s'affiche en haut avec "Your site is live at..."

### Comment rendre l'application privée ?
- Settings → General → Danger Zone → Change visibility
- ⚠️ Note : GitHub Pages privé nécessite un compte payant

---

## 📧 Besoin d'Aide ?

Si vous rencontrez des problèmes :
1. Vérifiez que tous les fichiers sont bien uploadés
2. Assurez-vous que le fichier s'appelle exactement `index.html`
3. Consultez https://docs.github.com/pages

---

**🎉 Félicitations ! Votre application est maintenant accessible partout !**
