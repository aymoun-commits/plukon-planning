# 🐔 Plukon Planning - Gestion de Production

Application web de gestion de planning pour la production agroalimentaire Plukon Food Group.

![License](https://img.shields.io/badge/license-MIT-green)
![Version](https://img.shields.io/badge/version-1.0.0-blue)

## 🌟 Fonctionnalités

### Planning en Temps Réel
- ✅ **18 lignes de production** configurables
- ✅ **Drag & Drop** intuitif pour affecter les employés
- ✅ **Gestion des capacités** par ligne (modifiable)
- ✅ **Alertes de surcapacité** automatiques

### Gestion des Équipes
- 🌅 **Équipe Matin** (06:30)
- 🌆 **Équipe Après-midi** (14:41)
- 📅 **Planning par date**
- 👥 **40 employés** par défaut (personnalisable)

### Import/Export
- 📥 **Import Excel** (.xlsx) - Liste des employés
- 📤 **Export Excel** - Sauvegarde de la liste
- 📄 **Export PDF** - Planning avec logo Plukon
- 💾 **Sauvegarde locale** automatique

### Historique
- 📋 **Historique complet** des plannings générés
- 📂 **Chargement rapide** des anciens plannings
- 📄 **Export PDF direct** depuis l'historique
- 🗑️ **Gestion** (supprimer individuellement ou tout l'historique)

### Gestion des Employés
- ➕ **Ajouter** des employés manuellement
- ✏️ **Modifier** nom et compétence
- 🗑️ **Supprimer** des employés
- 📥 **Import massif** via Excel
- 🔍 **Recherche** par nom ou compétence

## 🚀 Utilisation

### Accès Direct en Ligne
**🌐 [Ouvrir l'application](https://votre-username.github.io/plukon-planning/)**

*Remplacez `votre-username` par votre nom d'utilisateur GitHub*

### Installation Locale

1. **Télécharger le fichier**
   ```bash
   git clone https://github.com/votre-username/plukon-planning.git
   cd plukon-planning
   ```

2. **Ouvrir dans le navigateur**
   - Double-cliquez sur `index.html`
   - Ou glissez-déposez dans votre navigateur

### Utilisation Sans Installation
- Téléchargez simplement `index.html`
- Ouvrez-le dans n'importe quel navigateur moderne
- Aucune connexion internet requise après le premier chargement

## 📖 Guide d'Utilisation

### 1. Configuration Initiale
1. Importez votre liste d'employés via Excel ou ajoutez-les manuellement
2. Sélectionnez la date et l'équipe (Matin/Après-midi)

### 2. Affectation des Employés
1. **Glissez** un employé depuis la liste de gauche
2. **Déposez** sur une ligne de production
3. Les affectations sont **sauvegardées automatiquement**

### 3. Gestion des Capacités
- Cliquez sur le bouton "Max: X" pour modifier la capacité d'une ligne
- Une alerte ⚠️ apparaît en cas de surcapacité

### 4. Export du Planning
- **PDF** : Bouton "📄 Exporter PDF" - Génère un PDF professionnel avec logo
- **Historique** : Accédez à tous vos plannings via "📋 Historique"

### 5. Import Excel
Format attendu pour l'import :
```
Nom                  | Compétence
---------------------|------------------
Dupont Jean          | Découpe
Martin Claire        | Emballage
```

## 🛠️ Technologies

- **HTML5** - Structure
- **CSS3** - Design responsive
- **JavaScript (Vanilla)** - Logique métier
- **jsPDF** - Génération PDF
- **SheetJS** - Import/Export Excel
- **LocalStorage** - Sauvegarde locale

## 💾 Données

### Sauvegarde Locale
- Les données sont stockées dans le **localStorage** du navigateur
- Aucune donnée n'est envoyée à un serveur
- **100% sécurisé et privé**

### Structure des Données
```javascript
{
  "assignments": { "l1": ["e1", "e3"] },  // Affectations par ligne
  "capacities": { "l1": 7 },               // Capacités personnalisées
  "employees": [...],                      // Liste des employés
  "history": [...]                         // Historique des plannings
}
```

## 🎨 Personnalisation

### Modifier les Lignes de Production
Éditez le tableau `lines` dans le code :
```javascript
const lines = [
  { id: 'l1', name: 'Ligne 1 – Découpe A', defaultCapacity: 7 },
  // Ajoutez vos lignes ici
];
```

### Changer les Couleurs
Variables CSS principales :
```css
--plukon-green: #009639;
--plukon-red: #ED1C24;
```

## 📱 Compatibilité

- ✅ Chrome 90+
- ✅ Firefox 88+
- ✅ Edge 90+
- ✅ Safari 14+
- ✅ Mobile (iOS/Android)

## 🤝 Contribution

Les contributions sont les bienvenues !

1. Fork le projet
2. Créez une branche (`git checkout -b feature/amelioration`)
3. Committez vos changements (`git commit -m 'Ajout fonctionnalité'`)
4. Push vers la branche (`git push origin feature/amelioration`)
5. Ouvrez une Pull Request

## 📄 Licence

Ce projet est sous licence MIT. Voir le fichier [LICENSE](LICENSE) pour plus de détails.

## 👨‍💻 Auteur

Développé pour **Plukon Food Group**

## 📞 Support

Pour toute question ou problème :
- 🐛 [Ouvrir une issue](https://github.com/votre-username/plukon-planning/issues)
- 📧 Email: votre-email@example.com

## 🎯 Roadmap

- [ ] Mode multi-utilisateurs
- [ ] Synchronisation cloud
- [ ] Application mobile native
- [ ] Statistiques et rapports avancés
- [ ] Notifications par email
- [ ] Intégration API RH

## 📸 Captures d'Écran

### Interface Principale
![Planning View](screenshots/planning-view.png)

### Export PDF
![PDF Export](screenshots/pdf-export.png)

### Historique
![History View](screenshots/history-view.png)

---

**⭐ N'oubliez pas de mettre une étoile si ce projet vous est utile !**
